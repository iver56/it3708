class ObjectCollection(object):
    all_boids = []
    all_predators = []
    all_obstacles = []
